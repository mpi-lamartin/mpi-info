open Alphabet

(** Représentation d'une case du plateau.
    Quand une case est recouverte par une lettre, l'information de score
    présente initialement disparait. *)
type case =
	| Lettre of lettre
	| Centrale
	| Vide
	| LettreDouble
	| LettreTriple
	| MotDouble
	| MotTriple

(** Indique si une case est recouverte d'une lettre. *)
let case_est_vide case =
	match case with
	| Lettre(_) -> false
	| _ -> true

(** Type représentant les plateaux. On les suppose toujours carrés et on
	suppose que pour un plateau vide, il existe une unique case "Centrale". *)
type plateau = case array array

(** Création d'un plateau vide, sans aucun mot. *)
let nouveau_plateau () =
	let plateau = Array.make_matrix 15 15 Vide in
	(* diagonales en mot compte double, à réaliser en premier
	car pour les cases de milieu on écrasera par d'autres valeurs ensuite (pour
	avoir un code de génération du plateau un peu plus régulier) *)
	for i = 1 to Array.length plateau - 2 do
		plateau.(i).(i) <- MotDouble;
		plateau.(i).(Array.length plateau - 1 - i) <- MotDouble
	done;
	(* lignes de lettres triples *)
	for i = 0 to 3 do
		plateau.(5).(4*i+1) <- LettreTriple;
		plateau.(9).(4*i+1) <- LettreTriple;
		plateau.(4*i+1).(5) <- LettreTriple;
		plateau.(4*i+1).(9) <- LettreTriple;
	done;
	(* Lettres doubles un peu en vrac *)
	List.iter (fun (i,j) ->
		plateau.(i).(j) <- LettreDouble;
		plateau.(Array.length plateau - i - 1).(j) <- LettreDouble;
		plateau.(i).(Array.length plateau.(i) - j - 1) <- LettreDouble;
		plateau.(Array.length plateau - i - 1).(Array.length plateau.(i) - j - 1) <- LettreDouble;
		let (i,j) = (j,i) in
		plateau.(i).(j) <- LettreDouble;
		plateau.(Array.length plateau - i - 1).(j) <- LettreDouble;
		plateau.(i).(Array.length plateau.(i) - j - 1) <- LettreDouble;
		plateau.(Array.length plateau - i - 1).(Array.length plateau.(i) - j - 1) <- LettreDouble;
	) [(3,0);(6,2);(7,3);(6,6)];
	(* Bords en mot triple *)
	for i = 0 to 2 do
		for j = 0 to 2 do
			plateau.(7*i).(7*j) <- MotTriple
		done
	done;
	plateau.(7).(7) <- Centrale;
	plateau

(** Affichage à l'écran d'un plateau sous une forme concise. *)
let affiche_plateau plateau =
	for i = 0 to Array.length plateau - 1 do
		for j = 0 to Array.length plateau.(i) - 1 do
			print_char (match plateau.(i).(j) with
			| Lettre(x) -> x
			| Centrale -> '*'
			| Vide -> '_'
			| LettreDouble -> 'd'
			| LettreTriple -> 't'
			| MotDouble -> '@'
			| MotTriple -> '$'
			)
		done;
		print_newline ()
	done

(* Ajout d'un mot sur un plateau, la première lettre étant en coordonnée (i,j).
   Le sens du placement du mot (horizontal ou vertical) est indiqué par le
   booléen [est_vertical]. Cette fonction n'effectue absolument aucune
   vérification sur le caractère correct ou non du placement demandé. *)
let place_mot plateau (i,j) est_vertical mot =
	for offset = 0 to String.length mot - 1 do
		let (i', j') =
			if est_vertical
                        then (i + offset, j)
                        else (i, j + offset)
		in
		plateau.(i').(j') <- Lettre(mot.[offset])
	done

(* Plateau correspondant à la figure donnée en exemple *)
let plateau_figure =
	let plateau = nouveau_plateau () in
	List.iter (fun (coord, horiz, mot) -> place_mot plateau coord horiz mot)
	[
		((6,8), false, "JOCISTE");
		((7,3), false, "PARADERAS");
		((11,3), false, "LEK");
		((11,9), false, "BIQUET");
		((12,0), false, "FRAISAGE");
		((13,7), false, "ENGOUERA");
		((14,0), false, "REELUTES");
		((14,10), false, "UNS");
		((0,14), true, "ENNOYIEZ");
		((3,1), true, "TAXI");
		((3,11), true, "HIAIS");
		((4,10), true, "NUCAL");
		((5,9), true, "MORIO");
		((6,0), true, "ACCOT");
		((6,4), true, "PAWNEES");
		((7,7), true, "DECODEES");
		((8,12), true, "FLEUVES");
		((9,1), true, "HEURTE");
		((9,14), true, "MITRAL");
	]; plateau


(** Un tirage correspond à l'ensemble des lettres qu'un joueur peut utiliser
	pour composer le mot suivant. *)
type tirage = lettre list

