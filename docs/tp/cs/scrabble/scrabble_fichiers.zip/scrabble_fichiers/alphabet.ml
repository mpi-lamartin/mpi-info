(** Type des lettres *)
type lettre = char

(** Les lettres sont dans ce sujet les caractères majuscules entre A et Z.
	Chaque lettre rapporte un nombre de points, fixé par la fonction suivante. *)
let points lettre =
	if List.mem lettre ['A'; 'E'; 'I'; 'L'; 'N'; 'O'; 'R'; 'S'; 'T'; 'U'] then 1
	else if List.mem lettre ['D'; 'G'; 'M'] then 2
	else if List.mem lettre ['B'; 'C'; 'P'] then 3
	else if List.mem lettre ['F'; 'H'; 'V'] then 4
	else if List.mem lettre ['J'; 'Q'] then 8
	else if List.mem lettre ['K'; 'W'; 'X'; 'Y'; 'Z'] then 10
	else invalid_arg "points"


(** Taille de l'alphabet considéré pendant le jeu.
    Le caractère spécial des ancres dans les GADDAG comptera pour une 27è lettre. *)
let nb_lettres = 26

(** Les lettres seront toujours entre A et Z. On donne deux fonctions pour les
	convertir depuis et vers des entiers entre 0 et 25. *)
let lettre_of_int x =
	if x = nb_lettres then '!'
	else char_of_int (x + int_of_char 'A')

let int_of_lettre x =
	if x = '!' then nb_lettres
	else int_of_char x - int_of_char 'A'
