open Printf

type bipartite = {
  n1 : int;
  adj : int list array
}

type matching = int option array

type path = int list

(* Un exemple *)

(* Un graphe biparti à 20+20 sommets. Ce graphe admet un couplage parfait. *)

let g20 = {
  n1 = 20;
  adj =
    [|[37; 34; 32; 31; 25; 22; 20]; [39; 38; 36; 24; 23; 20]; [36; 35; 30; 21];
      [35; 32; 28; 27]; [24; 23; 20]; [37; 34; 32; 27]; [34; 29; 27]; [38; 27];
      [39; 30; 26; 22; 20]; [39; 36]; [36; 31; 28; 27; 26; 25; 24; 23; 22; 21];
      [38; 33; 31]; [29]; [38; 36; 32; 23; 22; 20]; [33; 23]; [24]; [26];
      [39; 26]; [33; 29]; [39; 31; 28; 27]; [13; 8; 4; 1; 0]; [10; 2];
      [13; 10; 8; 0]; [14; 13; 10; 4; 1]; [15; 10; 4; 1]; [10; 0];
      [17; 16; 10; 8]; [19; 10; 7; 6; 5; 3]; [19; 10; 3]; [18; 12; 6];
      [8; 2]; [19; 11; 10; 0]; [13; 5; 3; 0]; [18; 14; 11]; [6; 5; 0];
      [3; 2]; [13; 10; 9; 2; 1]; [5; 0]; [13; 11; 7; 1]; [19; 17; 9; 8; 1]|]
}

(* Un couplage maximal pour l'inclusion, mais pas de cardinalité maximale, *)
(* pour g20. *)

let m20 = [|
  Some 20; Some 23; Some 21; Some 27; Some 24; Some 32; Some 29; Some 38;
  Some 22; Some 36; Some 25; Some 31; None; None; Some 33; None; Some 26;
  Some 39; None; Some 28; Some 0; Some 2; Some 8; Some 1; Some 4; Some 10;
  Some 16; Some 3; Some 19; Some 6; None; Some 11; Some 5; Some 14; None;
  None; Some 9; None; Some 7; Some 17
|]

(* 6 chemins élémentaires de g20. Seul le premier et le dernier sont *)
(* augmentants pour m20. *)

let p20_1 = [30; 8; 22; 0; 20; 1; 23; 14; 33; 11; 31; 19; 28; 3; 27; 6; 29; 12]
let p20_2 = [26; 8; 22; 0; 20; 1; 23; 14; 33; 11; 31; 19; 28; 3; 27; 6; 29; 12]
let p20_3 = [30; 8; 22; 0; 20; 1; 23; 14; 33; 11; 31; 19; 28; 3; 27; 6; 29]
let p20_4 = [30; 8; 22; 0; 20; 1; 23; 14; 33; 11; 31; 19; 28; 3; 27; 6]
let p20_5 = [30; 8; 22; 13; 20; 1; 23; 14; 33; 11; 31; 19; 28; 3; 27; 6; 29; 12]
let p20_6 = [34; 6; 29; 12]


(* Fonctions utilitaires fournies *)

let is_matching g m =
  let n = Array.length m in
  let rec check i =
    i = n
    || (
      match m.(i) with
      | None -> true
      | Some j ->
        0 <= j && j < n
        && List.mem i g.adj.(j)
        && m.(j) = Some i
        && check (i + 1)
    ) in
  check 0

let print_path p =
  List.iter (printf "%d ") p;
  print_newline ()

let print_matching m =
  for i = 0 to Array.length m - 1 do
    match m.(i) with
    | None -> printf "%d\n" i;
    | Some j ->
      match m.(j) with
      | Some k when k = i -> printf "%d-%d\n" i j;
      | Some k -> printf "!!!! %d-%d %d-%d\n" i j k j;
      | None -> printf "!!!! %d-%d  -%d\n" i j j
  done

let cardinal m =
  let nb = ref 0 in
  for i = 0 to Array.length m - 1 do
    if m.(i) <> None then incr nb
  done;
  !nb / 2

let random_bipartite n1 n2 p =
  let adj = Array.make (n1 + n2) [] in
  for i = 0 to n1 - 1 do
    for j = n1 to n1 + n2 - 1 do
      if Random.float 1. <= p then (
        adj.(i) <- j :: adj.(i);
        adj.(j) <- i :: adj.(j)
      )
    done;
  done;
  {adj; n1}

let print_bipartite g filename =
  let oc = open_out filename in
  let n = Array.length g.adj in
  let n2 = n - g.n1 in
  fprintf oc "%d %d\n" g.n1 n2;
  let process_vertex i =
    List.iter (fun j -> if i < j then fprintf oc "%d %d\n" i j) in
  Array.iteri process_vertex g.adj;
  close_out oc

let read_bipartite filename =
  let ic = Scanf.Scanning.open_in filename in
  let n1, n2 = Scanf.bscanf ic "%d %d\n" (fun x y -> (x, y)) in
  let g = {adj = Array.make (n1 + n2) []; n1 = n1} in
  try
    while true do
      let i, j = Scanf.bscanf ic "%d %d\n" (fun i j -> (i, j)) in
      g.adj.(i) <- j :: g.adj.(i);
      g.adj.(j) <- i :: g.adj.(j)
    done;
    assert false
  with
  | End_of_file -> Scanf.Scanning.close_in ic; g


(* À vous ! *)
